# frozen_string_literal: true

# Permitted locales available for the application
I18n.available_locales = %i[en pt de]
